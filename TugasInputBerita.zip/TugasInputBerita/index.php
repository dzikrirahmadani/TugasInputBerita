<?php
include 'koneksi.php';
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="style.css">
        <title>Index Berita</title>
        <script src="https://cdn.tailwindcss.com"></script>
    </head>
    <body>
        
        <nav class="w-full h-[50px] bg-blue-900 flex justify-center text-white text-[20px]">
            <ul class="flex">
                <li class="mt-2">
                    <a href="index.php" class="px-4 py-[15px] hover:bg-blue-600">Halaman Depan</a>
                </li>
                <li class="mt-2" class="px-4 py-[15px] hover:bg-blue-600">
                    <a href="arsip_berita.php" class="px-4 py-[15px] hover:bg-blue-600">Arsip Berita</a>
                </li>
                <li class="mt-2" class="px-4 py-[15px] hover:bg-blue-600">
                    <a href="input_berita.php" class="px-4 py-[15px] hover:bg-blue-600">Input Berita</a>
                </li>
            </ul>
        </nav>

        <h2 class="text-[50px] text-center">Halaman Depan ~ Lima Berita Terbaru</h2>
        <?php
            $query = "SELECT A.id_berita, B.nm_kategori, A.judul, A.headline, A.pengirim, A.tanggal FROM tbl_berita A, tbl_kategori B WHERE A.id_kategori = B.id_kategori ORDER BY A.id_berita DESC LIMIT 0,5";

            

            $sql = mysqli_query($koneksi, $query);
            while($hasil = mysqli_fetch_assoc($sql)){
                $id_berita = $hasil['id_berita'];
                $kategori = stripslashes($hasil['nm_kategori']);
                $judul = stripslashes($hasil['judul']);
                $headline = nl2br(stripslashes($hasil['headline']));
                $pengirim = stripslashes($hasil['pengirim']);
                $tanggal = stripslashes($hasil['tanggal']);

                // tampil berita
                echo "<font size=5><b><a href='berita_lengkap.php?id=$id_berita' target='_blank'>$judul</a></b></font><br>";
                echo "<img src='img/tenggelam_di_situ_gede.jpg' alt=''>";
                echo "<img src='img/tengggelam_di_situ_gede.jpg' alt=''><br>";
                echo "<small>Berita Dikirimkan Oleh <b>$pengirim</b> pada tanggal <b>$tanggal</b> dalam kategori <b>$kategori</b></small>";
                echo "<p>$headline</p>";
                echo "<hr>";

            }
        ?>
    </body>
</html>