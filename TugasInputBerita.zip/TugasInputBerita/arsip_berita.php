<?php
include 'koneksi.php';
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="style.css">
        <title>Arsip Berita</title>
        <script src="https://cdn.tailwindcss.com"></script>
        <script>
            const tanya = () => {
                if( confirm('Apakah anda yakin akan menghapus berita ini ?') ){
                    return true;
                }else{
                    return false;
                }
            }
        </script>
    </head>
    <body>
        
        <nav class="w-full h-[50px] bg-blue-900 flex justify-center text-white text-[20px]">
            <ul class="flex">
                <li class="mt-2">
                    <a href="index.php" class="px-4 py-[15px] hover:bg-blue-600">Halaman Depan</a>
                </li>
                <li class="mt-2" class="px-4 py-[15px] hover:bg-blue-600">
                    <a href="arsip_berita.php" class="px-4 py-[15px] hover:bg-blue-600">Arsip Berita</a>
                </li>
                <li class="mt-2" class="px-4 py-[15px] hover:bg-blue-600">
                    <a href="input_berita.php" class="px-4 py-[15px] hover:bg-blue-600">Input Berita</a>
                </li>
            </ul>
        </nav>

        <h2>Arsip Berita</h2>
        <ol>
            <?php
                $query = "SELECT A.id_berita, B.nm_kategori, A.judul, A.pengirim, A.tanggal FROM tbl_berita A, tbl_kategori B WHERE A.id_kategori = B.id_kategori ORDER BY A.id_berita DESC";

                $sql = mysqli_query($koneksi, $query);
                while($hasil = mysqli_fetch_assoc($sql)){
                    $id_berita = $hasil['id_berita'];
                    $kategori = stripslashes($hasil['nm_kategori']);
                    $judul = stripslashes($hasil['judul']);
                    $pengirim = stripslashes($hasil['pengirim']);
                    $tanggal = stripslashes($hasil['tanggal']);

                    // tampilkan berita
                    echo "<li><a href='berita_lengkap.php?id=$id_berita'>$judul</a><br>";
                    echo "<small>Berita dikirimkan oleh <b>$pengirim</b> pada tanggal <b>$tanggal</b> dalam kategori <b>$kategori</b></small></br>";    
                    echo "<b>Action : </b><a href='edit_berita.php?id=$id_berita'>Edit</a> | ";
                    echo "<a href='delete_berita.php?id=$id_berita' onclick='return tanya()'>Delete</a>";
                    echo "</small></li><br><br>";
                }
            ?>
        </ol>
    </body>
</html>