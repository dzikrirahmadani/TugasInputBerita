<?php
include 'koneksi.php';

if( isset ($_GET['id'])){
    $id_berita = $_GET['id'];
}else{
    die('Error. No Id Selected !');
}

$query = "SELECT id_berita, id_kategori, judul, headline, isi, pengirim, tanggal FROM tbl_berita WHERE id_berita = '$id_berita'";
$sql = mysqli_query($koneksi, $query);
$hasil = mysqli_fetch_array($sql);

$id_berita = $hasil['id_berita'];
$id_kategori = stripslashes($hasil['id_kategori']);
$judul = stripslashes($hasil['judul']);
$headline = stripslashes($hasil['headline']);
$isi = stripslashes($hasil['isi']);
$pengirim = stripslashes($hasil['pengirim']);
$tanggal = stripslashes($hasil['tanggal']);

// Proses edit berita
if(isset($_POST['Edit'])){
    $id_berita = $_POST['hidberita'];
    $judul = addslashes( strip_tags($_POST['judul']));
    $kategori = $_POST['kategori'];
    $headline = addslashes( strip_tags($_POST['headline']));
    $isi_berita = addslashes( strip_tags($_POST['isi']));
    $pengirim = addslashes( strip_tags($_POST['pengirim']));

    // update berita
    $query = "UPDATE tbl_berita SET
            id_kategori = '$kategori',
            judul = '$judul',
            headline = '$headline',
            isi = '$isi_berita',
            pengirim = '$pengirim'
            WHERE id_berita = '$id_berita'
            ";
    $sql = mysqli_query($koneksi, $query);
    if( $sql ){
        echo "<h2><font color=blue>Berita Telah Berhasil Diedit</font></h2>";
    }else{
        echo "<h2><font color=red>Berita Gagal Diedit</font><h2>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="style.css">
        <title>Edite Berita</title>
        <script src="https://cdn.tailwindcss.com"></script>
    </head>
    <body>

        <nav class="w-full h-[50px] bg-blue-900 flex justify-center text-white text-[20px]">
            <ul class="flex">
                <li class="mt-2">
                    <a href="index.php" class="px-4 py-[15px] hover:bg-blue-600">Halaman Depan</a>
                </li>
                <li class="mt-2" class="px-4 py-[15px] hover:bg-blue-600">
                    <a href="arsip_berita.php" class="px-4 py-[15px] hover:bg-blue-600">Arsip Berita</a>
                </li>
                <li class="mt-2" class="px-4 py-[15px] hover:bg-blue-600">
                    <a href="input_berita.php" class="px-4 py-[15px] hover:bg-blue-600">Input Berita</a>
                </li>
            </ul>
        </nav>

        <form action="" method="POST" name="input">
            <table cellpadding="0" cellspacing="" border="0" width="700">
                <tr>
                    <td colspan="2"><h2>Input Berita</h2></td>
                </tr>
                <tr>
                    <td width="200">Judul Berita</td>
                    <td>: <input type="text" name="judul" size="30" id="" value="<?= $judul?>" class="border-[1px] border-gray-900 rounded-full"></td>
                </tr>   
                <tr>
                    <td>Kategori</td>
                    <td>:
                        <select name="kategori" id="">
                            <?php
                                $query = "SELECT id_kategori, nm_kategori FROM tbl_kategori ORDER BY nm_kategori";
                                $sql = mysqli_query($koneksi, $query);
                                while($hasil = mysqli_fetch_array($sql)){
                                    $selected = ($hasil['id_kategori']==$id_kategori) ? "selected" : "";
                                    echo "<option value='-' selected disabled>- Pilih Kategori -</option>";
                                    echo "<option value='$hasil[id_kategori]' $selected>$hasil[nm_kategori]</option>";
                                }
                            ?>
                        </select>
                    </td>
                </tr>
                <tr>
                    <td>Headline Berita</td>
                    <td>: <textarea name="headline" id="" cols="50" rows="4" class="border-[1px] border-gray-900 rounded-[20px]"><?=$headline?></textarea></td>
                </tr>
                <tr>
                    <td>Isi Berita</td>
                    <td>: <textarea name="isi" id="" cols="50" rows="10" class="border-[1px] border-gray-900 rounded-[20px]"><?=$isi?></textarea></td>
                </tr>
                <tr>
                    <td>Pengirim</td>
                    <td>: <input type="text" name="pengirim" id="" size="20" value="<?=$pengirim?>" class="border-[1px] border-gray-900 rounded-full"></td>
                </tr>
                <tr>
                    <td>&nbsp;</td>
                    <td>&nbsp;&nbsp;
                        <input type="hidden" name="hidberita" value="<?=$id_berita?>">
                        <input type="submit" value="Edit Berita" name="Edit">&nbsp;
                        <input type="reset" value="Cancel" name="reset">
                    </td>
                </tr>
            </table>
        </form>
    </body>
</html>