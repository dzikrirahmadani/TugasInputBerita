<?php

$host = 'localhost';
$user = 'root';
$pass = '';
$db = 'pkl_input_berita';

// mysql connect
$koneksi = mysqli_connect($host, $user, $pass, $db);

// connect check
if( !$koneksi ){
    die('koneksi gagal : '.mysqli_connect_error());
}
